# Design System Specification: Stark Editorial

## 1. Overview & Creative North Star

### Creative North Star: "The Architectural Monolith"
This design system rejects the "standard" colorful UI in favor of a high-contrast, editorial experience that mirrors the precision of premium physical Swiss design. It is built on the tension between pure white voids and dense, heavy blacks. By removing the distraction of color, we force the user to focus on form, data, and motion.

The system breaks the "template" look through **Extreme Curvature** and **Intentional Weight**. We do not use thin, spindly lines for structure; we use the weight of the objects themselves—achieved through thick 2px strokes or expansive, soft-ambient shadows—to define the interactive landscape. It is "Soft Brutalism": structurally heavy, but visually approachable through its roundedness.

---

## 2. Colors & Tonal Depth

The palette is strictly grayscale, leveraging the Material Design logic to create a hierarchy of light and shadow rather than hue.

### The "No-Line" Rule
Traditional 1px dividers are strictly prohibited. Sectioning must be achieved through:
1.  **Background Shifts:** Transitioning from `surface` (#f9f9f9) to `surface-container-low` (#f3f3f3).
2.  **Object Mass:** Using `primary` (#000000) for high-impact containers.
3.  **Negative Space:** Utilizing the spacing scale to create invisible boundaries.

### Surface Hierarchy & Nesting
To create an "editorial" depth, treat the UI as stacked sheets of gallery paper.
*   **Base:** `surface` (#f9f9f9).
*   **The Inset Layer:** Use `surface-container-low` (#f3f3f3) for recessed backgrounds like task lists or secondary widgets.
*   **The Elevated Layer:** Use `surface-container-lowest` (#ffffff) for high-priority cards that need to "pop" via a large-spread shadow.

### The Glass & Gradient Rule
While the system is monochrome, it is not "flat." Use grayscale gradients to denote progress and depth:
*   **Gradients:** Use a transition from `primary` (#000000) to `primary-container` (#3b3b3b) in circular progress bars or line charts to create a "liquid ink" feel.
*   **Glassmorphism:** For floating navigation or modals, use `surface-container-lowest` with 80% opacity and a `24px` backdrop blur. This ensures the high-contrast elements beneath remain visible but diffused.

---

## 3. Typography

The typography system relies on the **Inter** typeface. It is the sole driver of the brand's authoritative voice.

*   **Display & Headline (The Statement):** Set in `Heavy` or `Bold` weights (700-900). The `display-lg` (3.5rem) should be used sparingly for "hero" moments, treated more like a graphic element than text.
*   **Body (The Utility):** Set in `Medium` (500) or `Regular` (400). Avoid `Light` weights as they disappear against the high-contrast background.
*   **Labels (The Detail):** Set in `Bold` and often uppercase to provide a "metadata" feel that contrasts against the fluid body text.

**Hierarchy Strategy:** Use `primary` (#000000) for all headers to command attention. Use `secondary` (#5f5e60) for body text to reduce visual fatigue, creating a sophisticated "washed" gray look for long-form reading.

---

## 4. Elevation & Depth

We replace structural lines with **Tonal Layering** and **Ambient Diffusion**.

*   **The Layering Principle:** Place a `surface-container-lowest` (#ffffff) card on a `surface` (#f9f9f9) background. This 1-step tonal shift provides enough "lift" for the eye without needing a border.
*   **Ambient Shadows:** For interactive cards (e.g., "Weekly Focus" cards), use a very large spread (32px - 64px) with a very low opacity (4% - 6%) using the `primary` hex. It should feel like a soft glow, not a hard drop shadow.
*   **The "Ghost Border" Fallback:** If a boundary is strictly required for accessibility (e.g., an input field), use a 2px stroke of `outline-variant` at 20% opacity. 
*   **Stark Borders:** For high-action items (Primary Buttons), use a solid 2px `primary` (#000000) border to anchor the element.

---

## 5. Components

### Shapes & Radii
*   **Extreme Rounds:** Use `xl` (3rem/48px) for major cards and `full` (9999px) for buttons/chips. The goal is a "pill-like" aesthetic that feels soft to the touch.

### Buttons
*   **Primary:** Solid `primary` (#000000) fill with `on-primary` (#e2e2e2) text. Full rounded corners. No shadow; its mass is its prominence.
*   **Secondary:** 2px `primary` border, transparent background.
*   **Tertiary:** Bold text only, with a `full` round hover state using `surface-container-high`.

### Input Fields
*   **Styling:** No bottom line. Use a `surface-container-highest` background with a `xl` corner radius. 
*   **States:** On focus, transition the background to `surface-container-lowest` and add a 2px `primary` border.

### Progress Indicators (The Signature Element)
*   **Circular Progress:** Use a thick (8px-12px) stroke. The "track" is `surface-container-highest`. The "indicator" is a grayscale gradient from `primary` to `primary-fixed`. 

### Cards & Lists
*   **Rule:** Forbid divider lines between list items. Use 16px of vertical white space and a subtle background change (`surface-container-low`) on hover to define the list item area.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use massive headings to create a sense of luxury and space.
*   **Do** embrace the white space. If a layout feels empty, add *more* padding, not more elements.
*   **Do** use grayscale gradients in data visualizations to provide a sense of "movement" that flat black cannot.
*   **Do** apply `text-wrap: balance` to headlines to ensure they look like intentional editorial blocks.

### Don't
*   **Don't** use 1px lines. They feel "default" and "cheap" in this context.
*   **Don't** introduce any color, even for success or warning, unless it is the system-defined `error` (#ba1a1a) used sparingly. Try to communicate "Success" through iconography and bold black text instead.
*   **Don't** use sharp corners. Every interactive element must be fluid and rounded.
*   **Don't** use "pure" black (#000000) for long-form body text; use `on-surface-variant` (#474747) to keep the experience premium and readable.